import hashlib

import pymysql


def get_md5(passwd):
    h = hashlib.md5()
    h.update(passwd.encode('utf-8'))
    return h.hexdigest()


class ids_log_mysql:
    def __init__(self):
        self.conn = pymysql.connect(
            host='127.0.0.1',
            user='root',
            password='root',
            db='ids_log',
            charset='utf8'
        )

    def update_ids_config(self, data):
        sql = "update ids_config set m_ip=%s,m_port=%s,ids_ip=%s,ids_port=%s,ids_model=%s where id = '1'"
        cursor = self.conn.cursor()
        cursor.execute(sql, (data["m_ip"], data["m_port"], data["ids_ip"], data["ids_port"], data["ids_model"]))
        self.conn.commit()

    def show_ids_config(self):  # 显示设置接口
        sql = "select * from ids_config "
        cursor = self.conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute(sql)
        return cursor.fetchall()

    def show_user(self):  # 显示用户接口
        sql = "select * from user"
        cursor = self.conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute(sql)
        return cursor.fetchall()

    def show_ids_logs(self):  # 显示数据接口
        sql = "select * from ids_logs"
        cursor = self.conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute(sql)
        return cursor.fetchall()

    def search_ids_logs(self, key):  # 查询接口
        key_ = "%" + key + "%"
        sql = "select * from ids_logs where ip like %s or time_ like %s or req_info like %s or evil_proda like %s"
        cursor = self.conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute(sql, (key_, key_, key_, key_))
        return cursor.fetchall()

    def check_user_and_md5_passwd(self, user, passwd):  # 判断用户和密码的接口
        md5_passwd = get_md5(passwd)
        u_p = self.show_user()
        if (u_p[0]["user"] == user) & (u_p[0]["passwd"] == md5_passwd):
            return True
        else:
            return False

    def show_time_by_key(self, key):  # 显示时间统计接口
        key = "%" + key + "%"
        sql = "select time_ from ids_logs where time_ like %s"
        cursor = self.conn.cursor(pymysql.cursors.DictCursor)
        cursor.execute(sql, key)
        time_ = cursor.fetchall()

        return time_
