import json
import re
from flask import Flask, jsonify, request
from ids_log_mysql import ids_log_mysql

app = Flask(__name__)


def count_time_(list_, time_count):
    for i in list_:
        if i in time_count.keys():
            time_count[i] += 1
        else:
            time_count[i] = 1
    return time_count


def dict_pie_list(data, dict_):
    for i in dict_:
        data.append({'name': i, 'value': dict_[i]})
        # a = {'name': 'A',
        # 'type': 'line',
        # 'smooth': True,
        # 'data': [18, 36, 65, 30, 78, 40, 33]}


def dict_line_list(data, dict_):
    for i in dict_:
        data0 = [0] * 24
        data0[int(i.split(' ')[1])] = dict_[i]
        data.append({'name': i.split(' ')[0], 'type': 'line', 'smooth': True, 'data': data0})


@app.route('/set_config', methods=['GET', 'POST'])
def set_config():
    if request.method == 'POST':
        data = request.get_data()
        data = json.loads(data.decode("utf-8"))
        print(data)
        try:
            conn = ids_log_mysql()
            conn.update_ids_config(data)
        except Exception as e:
            return str(e)
        return "True"
    if request.method == 'GET':
        conn = ids_log_mysql()
        ids_config = conn.show_ids_config()
        return jsonify(ids_config[0])


@app.route('/check_user', methods=['GET'])
def check_user():
    if request.method == 'GET':
        user = request.args.get('user')
        passwd = request.args.get('passwd')
        if (user is not None) & (passwd is not None):
            conn = ids_log_mysql()
            return str(conn.check_user_and_md5_passwd(user, passwd))
        else:
            return 'None'
    else:
        return 'None'


@app.route('/show_logs')
def show_log():
    conn = ids_log_mysql()
    ids_logs = conn.show_ids_logs()
    print(ids_logs)
    return jsonify(ids_logs)


@app.route('/search', methods=['GET'])
def search():
    key = request.args.get("key")
    if key is not None:
        conn = ids_log_mysql()
        ids_logs = conn.search_ids_logs(key)
        return jsonify(ids_logs)


@app.route('/statistics', methods=['GET', 'POST'])
def statistics():
    time_y = []
    time_m = []
    time_d = []
    time_h = []
    time_count = {}
    data = []
    text = []
    key = None
    key_list = []
    if request.method == 'GET':
        key = request.args.get("key")
    if request.method == 'POST':
        data_ = request.get_json()
        key_list = data_['key_list']
    if (key is not None) or (key_list is not None):
        conn = ids_log_mysql()
        if key is None:
            for i in key_list:
                text += conn.show_time_by_key(i)
            key = key_list[0]
        elif key is not None:
            text = conn.show_time_by_key(key)
        for i in text:
            time_y.append(i['time_'].split('-')[0])
            time_m.append(i['time_'].split('-', -1)[0] + '-' + i['time_'].split('-', -1)[1])
            time_d.append(i['time_'].split(' ')[0])
            time_h.append(i['time_'].split(':')[0])

        if re.match(r'\d\d\d\d-\d\d-\d\d', key):
            count_time_(time_h, time_count)
            dict_line_list(data, time_count)
            return jsonify(data)
        elif re.match(r'\d\d\d\d-\d\d', key):  # 请求月份
            count_time_(time_d, time_count)  # 根据标签的个数 生成一个 {标签:个数，...} 的字典
            dict_pie_list(data, time_count)  # 把字典转换成[{name:标签，value:个数},{}，...]的列表
            return jsonify(data)
        elif re.match(r'\d\d\d\d', key):
            count_time_(time_m, time_count)
            dict_pie_list(data, time_count)
            return jsonify(data)
        else:
            count_time_(time_y, time_count)
            dict_pie_list(data, time_count)
            return jsonify(data)
    else:
        return jsonify(data)


if __name__ == '__main__':
    app.run(debug=True)
